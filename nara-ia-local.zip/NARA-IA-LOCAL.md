# Nara — IA local experimental

Esta versão substitui a chamada obrigatória à API da xAI/Grok por inferência local no navegador usando WebLLM e WebGPU.

## Modelo inicial

- Modelo: `Qwen2.5-1.5B-Instruct-q4f16_1-MLC`
- Biblioteca: `@mlc-ai/web-llm`
- Download inicial aproximado: 1,6 GB (pode variar por versão e arquivos de runtime).
- O WebLLM mantém os arquivos em cache local do navegador quando o armazenamento permite.

## Como funciona

1. A interface envia a conversa diretamente para `src/lib/nara-local-ai.ts`.
2. Na primeira pergunta, o navegador baixa o modelo e os recursos de runtime necessários.
3. As mensagens são processadas pelo modelo no aparelho. Este caminho não chama a API da Grok ou da OpenAI e não exige `XAI_API_KEY`.
4. A interface, os modos e o histórico existentes são mantidos.

## Limitações importantes

- É necessário um navegador compatível com WebGPU. O suporte no Android depende da versão do navegador, do sistema e dos drivers; deve ser validado no Galaxy A55 real.
- A primeira inicialização exige internet e espaço livre. Não prometa funcionamento totalmente offline até testar que modelo e runtime estão em cache.
- Um modelo local de 1,5B é menos capaz do que os grandes modelos na nuvem. A velocidade e o consumo de memória variam conforme o dispositivo.
- Se o navegador não tiver WebGPU, a aplicação apresenta uma mensagem clara; não muda silenciosamente para uma API paga.
- Esta versão é uma integração experimental e precisa de teste de build e de aparelho antes de ser considerada pronta para produção.

## Desenvolvimento

Instale as dependências usando `npm install`, depois execute `npm run typecheck`, `npm test` e `npm run build`. O `package-lock.json` deve ser regenerado por `npm install` no ambiente com acesso ao npm registry.
