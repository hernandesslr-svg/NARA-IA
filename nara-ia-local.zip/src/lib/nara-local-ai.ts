import type { ModeId } from "@/lib/nara-modes";

type ChatTurn = { role: "user" | "assistant"; content: string };
type ProgressCallback = (message: string) => void;

// Modelo compacto, quantizado e executado no próprio navegador via WebGPU.
// O WebLLM mantém os arquivos do modelo em cache local depois do primeiro download.
const MODEL_ID = "Qwen2.5-1.5B-Instruct-q4f16_1-MLC";

async function createEngine(onProgress: ProgressCallback) {
  const { CreateMLCEngine } = await import("@mlc-ai/web-llm");
  return CreateMLCEngine(MODEL_ID, {
    initProgressCallback: (report) => {
      onProgress(report.text || "Preparando o modelo local...");
    },
  });
}

type LocalEngine = Awaited<ReturnType<typeof createEngine>>;
let enginePromise: Promise<LocalEngine> | null = null;

function systemPrompt(mode: ModeId) {
  const base =
    "Você é Nara, uma assistente pessoal de IA que fala português do Brasil. Seja útil, clara, natural e honesta. Não invente fatos ou fontes; diga quando não souber. Como você roda localmente, não afirme ter pesquisado na internet nem ter acessado dados externos.";
  if (mode === "explicar") {
    return `${base} Modo explicar: apresente a ideia principal, dê um exemplo simples e termine com um breve resumo.`;
  }
  if (mode === "escrever") {
    return `${base} Modo escrever: entregue primeiro o texto pronto para copiar. Evite introduções desnecessárias.`;
  }
  if (mode === "planejar") {
    return `${base} Modo planejar: organize a resposta em passos concretos, em ordem, começando pelo que pode ser feito hoje.`;
  }
  return base;
}

async function getEngine(onProgress: ProgressCallback) {
  if (!("gpu" in navigator) || !(navigator as Navigator & { gpu?: unknown }).gpu) {
    throw new Error(
      "Este navegador não disponibiliza WebGPU para a IA local. Abra a Nara em uma versão atualizada do Chrome e verifique se o aparelho/navegador oferece suporte a WebGPU. Nenhuma API paga foi chamada."
    );
  }

  if (!enginePromise) {
    enginePromise = createEngine(onProgress).catch((error: unknown) => {
      // Permite tentar novamente depois de falha de download, memória ou inicialização.
      enginePromise = null;
      throw error;
    });
  }
  return enginePromise;
}

export async function askNaraLocally(
  mode: ModeId,
  messages: ChatTurn[],
  onProgress: ProgressCallback = () => undefined,
): Promise<string> {
  onProgress("Preparando a IA local...");

  let engine: LocalEngine;
  try {
    engine = await getEngine(onProgress);
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("Este navegador")) throw error;
    throw new Error(
      "Não consegui iniciar o modelo local. Confira a conexão para o primeiro download, libere memória e tente novamente. Detalhe: " +
        (error instanceof Error ? error.message : "erro desconhecido")
    );
  }

  onProgress("Nara está gerando a resposta no aparelho...");
  const result = await engine.chat.completions.create({
    messages: [
      { role: "system", content: systemPrompt(mode) },
      ...messages.map((message) => ({ role: message.role, content: message.content })),
    ],
    temperature: 0.7,
    top_p: 0.9,
    max_tokens: 700,
  });

  const text = result.choices?.[0]?.message?.content;
  if (typeof text !== "string" || !text.trim()) {
    throw new Error("O modelo local não produziu uma resposta. Tente uma pergunta mais curta.");
  }
  return text.trim();
}

export const LOCAL_AI_MODEL = MODEL_ID;
