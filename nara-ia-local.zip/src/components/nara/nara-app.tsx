import { ArrowUp, Menu, Plus, Trash2, X } from "lucide-react";
import { useEffect, useId, useRef, useState } from "react";
import { askNaraLocally } from "@/lib/nara-local-ai";
import { MODES, modeById, type ModeId } from "@/lib/nara-modes";
import {
  activeChat,
  appendAssistantMessage,
  appendUserMessage,
  deleteChat,
  selectChat,
  setDraftMode,
  startNewChat,
  useNaraState,
} from "@/lib/nara-store";
import { MessageBody } from "@/components/nara/message-body";

const SUGGESTIONS = [
  { label: "Explica inflação com um exemplo de mercado", mode: "explicar" as const },
  { label: "Escreve um e-mail curto pedindo um prazo", mode: "escrever" as const },
  { label: "Monta um plano de 7 dias para ler mais", mode: "planejar" as const },
  { label: "Qual a diferença entre hábito e rotina?", mode: "livre" as const },
];

export function NaraApp() {
  const snapshot = useNaraState();
  const chat = activeChat(snapshot);
  const mode = chat?.mode ?? snapshot.draftMode;
  const [draft, setDraft] = useState("");
  const [pending, setPending] = useState(false);
  const [aiStatus, setAiStatus] = useState("Preparando a IA local...");
  const [error, setError] = useState<string | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const threadRef = useRef<HTMLDivElement>(null);
  const fieldRef = useRef<HTMLTextAreaElement>(null);
  const fieldId = useId();

  useEffect(() => {
    const node = threadRef.current;
    if (!node) return;
    node.scrollTo({ top: node.scrollHeight });
  }, [chat?.messages.length, pending, chat?.id]);

  useEffect(() => {
    const node = fieldRef.current;
    if (!node) return;
    node.style.height = "0px";
    node.style.height = `${Math.min(node.scrollHeight, 160)}px`;
  }, [draft]);

  async function send(text: string, nextMode: ModeId = mode) {
    const content = text.trim();
    if (!content || pending) return;
    if (nextMode !== mode) setDraftMode(nextMode);
    setError(null);
    setDraft("");
    const messages = appendUserMessage(content, nextMode);
    setPending(true);
    try {
      const response = await askNaraLocally(
        nextMode,
        messages.slice(-12).map((message) => ({
          role: message.role,
          content: message.content,
        })),
        setAiStatus,
      );
      appendAssistantMessage(response);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não consegui falar com a Nara.");
    } finally {
      setPending(false);
      fieldRef.current?.focus();
    }
  }

  const meta = modeById(mode);
  const showEmpty = (!chat || chat.messages.length === 0) && !pending;

  return (
    <div className="grid h-dvh grid-cols-1 bg-paper text-ink md:grid-cols-[17.5rem_minmax(0,1fr)]">
      <aside className="hidden min-h-0 flex-col border-r border-line bg-panel md:flex">
        <Sidebar
          activeId={chat?.id ?? null}
          mode={mode}
          onNew={() => {
            startNewChat();
            setError(null);
          }}
          onSelect={(id) => {
            selectChat(id);
            setError(null);
          }}
          onDelete={deleteChat}
          onMode={setDraftMode}
        />
      </aside>

      <section className="flex min-h-0 min-w-0 flex-col">
        <header className="flex items-center gap-3 border-b border-line px-4 py-3 md:px-6">
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-lg border border-line bg-card text-ink md:hidden"
            aria-label="Abrir conversas"
            onClick={() => setHistoryOpen(true)}
          >
            <Menu className="size-5" strokeWidth={1.75} />
          </button>
          <div className="min-w-0 flex-1">
            <p className="font-display text-xl leading-none font-medium tracking-tight">
              <span className="md:hidden">Nara</span>
              <span className="hidden md:inline">{meta.label}</span>
            </p>
            <p className="mt-1 truncate text-sm text-muted">{meta.hint}</p>
          </div>
          <button
            type="button"
            className="inline-flex h-11 items-center gap-2 rounded-lg border border-line bg-card px-3 text-sm font-medium md:hidden"
            onClick={() => {
              startNewChat();
              setError(null);
            }}
          >
            <Plus className="size-4" strokeWidth={1.75} />
            Nova
          </button>
        </header>

        <div ref={threadRef} className="min-h-0 flex-1 overflow-y-auto">
          <div className="mx-auto flex min-h-full w-full max-w-3xl flex-col px-4 py-6 md:px-6">
            {showEmpty ? (
              <div className="flex flex-1 flex-col justify-end pb-6">
                <h1 className="max-w-xl font-display text-4xl leading-tight font-medium tracking-tight text-balance">
                  Pergunte, peça um texto ou um plano.
                </h1>
                <p className="mt-3 max-w-lg text-muted">
                  A Nara responde de verdade. Escolha um modo ou comece por uma destas ideias.
                </p>
                <div className="mt-6 grid gap-2 sm:grid-cols-2">
                  {SUGGESTIONS.map((item) => (
                    <button
                      key={item.label}
                      type="button"
                      className="rounded-xl border border-line bg-card px-4 py-3 text-left text-sm leading-snug transition-transform duration-150 hover:bg-paper active:scale-[0.98]"
                      onClick={() => void send(item.label, item.mode)}
                    >
                      <span className="block text-xs font-medium tracking-wide text-faint uppercase">
                        {modeById(item.mode).label}
                      </span>
                      <span className="mt-1 block">{item.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <ol className="flex flex-col gap-6">
                {chat?.messages.map((message) => (
                  <li key={message.id} className={message.role === "user" ? "msg-in flex justify-end" : "msg-in"}>
                    {message.role === "user" ? (
                      <div className="max-w-[85%] rounded-xl bg-accent px-4 py-3 text-accent-fg">
                        <p className="whitespace-pre-wrap text-pretty">{message.content}</p>
                      </div>
                    ) : (
                      <div className="max-w-[42rem]">
                        <p className="mb-2 text-xs font-medium tracking-wide text-faint uppercase">Nara</p>
                        <MessageBody text={message.content} />
                      </div>
                    )}
                  </li>
                ))}
                {pending ? (
                  <li className="msg-in">
                    <p className="shimmer-text text-sm font-medium">{aiStatus}</p>
                    <p className="mt-1 text-xs text-muted">A primeira inicialização pode baixar o modelo (cerca de 1,6 GB). A geração acontece no aparelho; não usa créditos de API.</p>
                  </li>
                ) : null}
              </ol>
            )}
          </div>
        </div>

        <div className="border-t border-line bg-paper px-4 pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:px-6">
          <form
            className="mx-auto w-full max-w-3xl"
            onSubmit={(event) => {
              event.preventDefault();
              void send(draft);
            }}
          >
            <div className="mb-2 flex gap-2 overflow-x-auto md:hidden">
              {MODES.map((item) => {
                const selected = item.id === mode;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-pressed={selected}
                    className={
                      selected
                        ? "h-10 shrink-0 rounded-lg bg-accent px-3 text-sm font-medium text-accent-fg"
                        : "h-10 shrink-0 rounded-lg border border-line bg-card px-3 text-sm text-ink"
                    }
                    onClick={() => setDraftMode(item.id)}
                  >
                    {item.label}
                  </button>
                );
              })}
            </div>
            {error ? (
              <p className="mb-2 text-sm text-danger" role="alert">
                {error}
              </p>
            ) : null}
            <label htmlFor={fieldId} className="sr-only">
              Mensagem
            </label>
            <div className="flex items-end gap-2 rounded-xl border border-line bg-card p-2">
              <textarea
                id={fieldId}
                ref={fieldRef}
                rows={1}
                value={draft}
                maxLength={4000}
                placeholder={meta.placeholder}
                disabled={pending}
                className="max-h-40 min-h-11 flex-1 resize-none bg-transparent px-2 py-2.5 text-base outline-none placeholder:text-faint disabled:opacity-60"
                onChange={(event) => setDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    void send(draft);
                  }
                }}
              />
              <button
                type="submit"
                disabled={pending || draft.trim().length === 0}
                aria-label="Enviar"
                className="inline-flex size-11 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-fg transition-transform duration-150 active:scale-[0.98] disabled:opacity-40"
              >
                <ArrowUp className="size-5" strokeWidth={1.75} />
              </button>
            </div>
            <p className="mt-2 text-center text-xs text-faint">IA local experimental. O modelo é baixado uma vez; as respostas são geradas no aparelho.</p>
          </form>
        </div>
      </section>

      {historyOpen ? (
        <div className="fixed inset-0 z-20 md:hidden">
          <button
            type="button"
            className="absolute inset-0 bg-ink/30"
            aria-label="Fechar conversas"
            onClick={() => setHistoryOpen(false)}
          />
          <div className="absolute inset-y-0 left-0 flex w-72 max-w-full flex-col bg-panel">
            <div className="flex items-center justify-between px-4 py-3">
              <p className="font-display text-xl font-medium">Conversas</p>
              <button
                type="button"
                className="inline-flex size-11 items-center justify-center rounded-lg"
                aria-label="Fechar"
                onClick={() => setHistoryOpen(false)}
              >
                <X className="size-5" strokeWidth={1.75} />
              </button>
            </div>
            <Sidebar
              activeId={chat?.id ?? null}
              mode={mode}
              onNew={() => {
                startNewChat();
                setError(null);
                setHistoryOpen(false);
              }}
              onSelect={(id) => {
                selectChat(id);
                setError(null);
                setHistoryOpen(false);
              }}
              onDelete={deleteChat}
              onMode={setDraftMode}
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Sidebar({
  activeId,
  mode,
  onNew,
  onSelect,
  onDelete,
  onMode,
}: {
  activeId: string | null;
  mode: ModeId;
  onNew: () => void;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onMode: (mode: ModeId) => void;
}) {
  const snapshot = useNaraState();
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="px-4 pt-4 pb-2">
        <p className="hidden font-display text-2xl leading-none font-medium tracking-tight md:block">Nara</p>
        <button
          type="button"
          className="mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-accent text-sm font-medium text-accent-fg transition-transform duration-150 active:scale-[0.98]"
          onClick={onNew}
        >
          <Plus className="size-4" strokeWidth={1.75} />
          Nova conversa
        </button>
      </div>
      <div className="px-3 py-2">
        <p className="px-2 pb-2 text-xs font-medium tracking-wide text-faint uppercase">Modo</p>
        <div className="grid gap-1">
          {MODES.map((item) => {
            const selected = item.id === mode;
            return (
              <button
                key={item.id}
                type="button"
                aria-pressed={selected}
                className={
                  selected
                    ? "rounded-lg bg-card px-3 py-2 text-left"
                    : "rounded-lg px-3 py-2 text-left hover:bg-card/70"
                }
                onClick={() => onMode(item.id)}
              >
                <span className="block text-sm font-medium">{item.label}</span>
                <span className="block text-xs text-muted">{item.hint}</span>
              </button>
            );
          })}
        </div>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-4">
        <p className="px-2 pt-3 pb-2 text-xs font-medium tracking-wide text-faint uppercase">Recentes</p>
        {snapshot.chats.length === 0 ? (
          <p className="px-2 text-sm text-muted">Nenhuma conversa ainda.</p>
        ) : (
          <ul className="grid gap-1">
            {snapshot.chats.map((item) => {
              const selected = item.id === activeId;
              return (
                <li key={item.id} className="group flex items-center gap-1">
                  <button
                    type="button"
                    className={
                      selected
                        ? "min-w-0 flex-1 truncate rounded-lg bg-card px-3 py-2 text-left text-sm"
                        : "min-w-0 flex-1 truncate rounded-lg px-3 py-2 text-left text-sm hover:bg-card/70"
                    }
                    onClick={() => onSelect(item.id)}
                  >
                    {item.title || "Conversa"}
                  </button>
                  <button
                    type="button"
                    aria-label={`Apagar ${item.title || "conversa"}`}
                    className="inline-flex size-10 shrink-0 items-center justify-center rounded-lg text-muted opacity-100 hover:text-ink md:opacity-0 md:group-hover:opacity-100 md:focus-visible:opacity-100"
                    onClick={() => onDelete(item.id)}
                  >
                    <Trash2 className="size-4" strokeWidth={1.75} />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
