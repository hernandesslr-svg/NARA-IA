# Nara IA — preparação para APK Android

O repositório usa Vite + React + Capacitor e inclui um workflow do GitHub Actions para gerar APK debug.

## Gerar APK
1. Abra a aba Actions deste repositório.
2. Selecione Build Android APK e clique em Run workflow na branch main.
3. Ao concluir, baixe o artefato nara-debug-apk no resultado da execução.

O APK é de desenvolvimento, não uma versão release assinada. O modelo local experimental exige internet no primeiro download (cerca de 1,6 GB) e suporte WebGPU no Android WebView; isso precisa ser testado no aparelho real.

## Pesquisa na internet (sem backend)
Quando o núcleo não tem a resposta, ou a pergunta pede algo atual, a Nara pesquisa direto do aparelho no Google, DuckDuckGo, Bing e Wikipedia. Ela prioriza fontes confiáveis (gov, edu, Wikipedia, grandes veículos), lê as páginas e responde citando os links.

Não precisa de servidor nem de proxy. No APK, o plugin CapacitorHttp (ativado em `capacitor.config.json`) faz as requisições pelo código nativo do Android, sem bloqueio de CORS. No navegador comum (`npm run dev`) a busca será bloqueada por CORS; teste no APK.
