import { useState } from "react";
import { CORE_LIMITS, TRAINED_VOICE } from "@/lib/nara-core";
import {
  addFact,
  addLesson,
  removeFact,
  removeLesson,
  resetCore,
  saveVoice,
  useNaraCore,
} from "@/lib/nara-core-store";

export function NaraCorePanel() {
  const core = useNaraCore();
  const [voice, setVoice] = useState(core.voice);
  const [fact, setFact] = useState("");
  const [ask, setAsk] = useState("");
  const [reply, setReply] = useState("");
  const dirty = voice.trim() !== core.voice;

  return (
    <div>
      <div className="mx-auto flex w-full max-w-3xl flex-col gap-8 px-4 py-6 md:px-6">
        <div>
          <h1 className="font-display text-3xl leading-tight font-medium tracking-tight text-balance">
            Núcleo treinado
          </h1>
          <p className="mt-2 max-w-xl text-muted">
            O treino de fábrica cobre a voz, {core.facts.length} fatos e {core.lessons.length} lições. Cada resposta leva o máximo que cabe, com prioridade para o que você acabou de perguntar.
          </p>
        </div>

        <section className="grid gap-3">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="text-sm font-medium">Voz</h2>
            <button
              type="button"
              className="text-sm text-muted underline-offset-2 hover:text-ink hover:underline"
              onClick={() => {
                resetCore();
                setVoice(TRAINED_VOICE);
              }}
            >
              Restaurar treino
            </button>
          </div>
          <textarea
            value={voice}
            rows={10}
            maxLength={CORE_LIMITS.voice}
            onChange={(event) => setVoice(event.target.value)}
            className="min-h-44 w-full resize-y rounded-xl border border-line bg-card px-4 py-3 text-sm leading-relaxed outline-none"
          />
          <button
            type="button"
            disabled={!dirty || voice.trim().length === 0}
            className="inline-flex h-11 items-center justify-center self-start rounded-lg bg-accent px-4 text-sm font-medium text-accent-fg disabled:opacity-40"
            onClick={() => saveVoice(voice)}
          >
            Guardar voz
          </button>
        </section>

        <section className="grid gap-3">
          <h2 className="text-sm font-medium">Fatos</h2>
          <ul className="grid gap-2">
            {core.facts.length === 0 ? <li className="text-sm text-muted">Nenhum fato ainda.</li> : null}
            {core.facts.map((item, index) => (
              <li key={`${item}-${index}`} className="flex items-start gap-3 rounded-lg bg-card px-3 py-2">
                <p className="min-w-0 flex-1 text-sm">{item}</p>
                <button type="button" className="text-sm text-muted hover:text-ink" onClick={() => removeFact(index)}>
                  Tirar
                </button>
              </li>
            ))}
          </ul>
          <form
            className="flex gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              addFact(fact);
              setFact("");
            }}
          >
            <input
              value={fact}
              maxLength={CORE_LIMITS.fact}
              placeholder="Um fato que a Nara deve tratar como verdade"
              onChange={(event) => setFact(event.target.value)}
              className="h-11 min-w-0 flex-1 rounded-lg border border-line bg-card px-3 text-sm outline-none placeholder:text-faint"
            />
            <button
              type="submit"
              disabled={fact.trim().length === 0 || core.facts.length >= CORE_LIMITS.facts}
              className="h-11 shrink-0 rounded-lg border border-line bg-card px-3 text-sm font-medium disabled:opacity-40"
            >
              Incluir
            </button>
          </form>
        </section>

        <section className="grid gap-3 pb-8">
          <h2 className="text-sm font-medium">Lições</h2>
          <p className="text-sm text-muted">Cada lição é um par: o que a pessoa diz e como a Nara deve responder.</p>
          <ul className="grid gap-3">
            {core.lessons.map((lesson) => (
              <li key={lesson.id} className="rounded-xl border border-line bg-card p-4">
                <p className="text-xs font-medium tracking-wide text-faint uppercase">Pessoa</p>
                <p className="mt-1 text-sm">{lesson.user}</p>
                <p className="mt-3 text-xs font-medium tracking-wide text-faint uppercase">Nara</p>
                <p className="mt-1 text-sm whitespace-pre-wrap">{lesson.assistant}</p>
                <button
                  type="button"
                  className="mt-3 text-sm text-muted hover:text-ink"
                  onClick={() => removeLesson(lesson.id)}
                >
                  Tirar lição
                </button>
              </li>
            ))}
          </ul>
          <form
            className="grid gap-2 rounded-xl border border-line bg-paper p-3"
            onSubmit={(event) => {
              event.preventDefault();
              addLesson({ user: ask, assistant: reply });
              setAsk("");
              setReply("");
            }}
          >
            <label className="grid gap-1 text-sm">
              Pessoa
              <textarea
                value={ask}
                rows={2}
                maxLength={CORE_LIMITS.user}
                onChange={(event) => setAsk(event.target.value)}
                className="resize-none rounded-lg border border-line bg-card px-3 py-2 outline-none"
              />
            </label>
            <label className="grid gap-1 text-sm">
              Como a Nara responde
              <textarea
                value={reply}
                rows={3}
                maxLength={CORE_LIMITS.assistant}
                onChange={(event) => setReply(event.target.value)}
                className="resize-none rounded-lg border border-line bg-card px-3 py-2 outline-none"
              />
            </label>
            <button
              type="submit"
              disabled={ask.trim().length === 0 || reply.trim().length === 0 || core.lessons.length >= CORE_LIMITS.lessons}
              className="inline-flex h-11 items-center justify-center rounded-lg bg-accent px-4 text-sm font-medium text-accent-fg disabled:opacity-40"
            >
              Treinar com esta lição
            </button>
            {core.lessons.length >= CORE_LIMITS.lessons ? (
              <p className="text-xs text-muted">Trinta e seis lições é o máximo. Tire uma para incluir outra.</p>
            ) : null}
          </form>
        </section>
      </div>
    </div>
  );
}
