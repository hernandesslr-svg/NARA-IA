import type { ReactNode } from "react";

function inline(text: string): ReactNode[] {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.filter(Boolean).map((part, index) => {
    if (part.startsWith("**") && part.endsWith("**") && part.length > 4) {
      return (
        <strong key={index} className="font-semibold">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith("`") && part.endsWith("`") && part.length > 2) {
      return (
        <code key={index} className="rounded-sm bg-panel px-1 py-0.5 font-sans text-sm">
          {part.slice(1, -1)}
        </code>
      );
    }
    return <span key={index}>{part}</span>;
  });
}

type Block =
  | { type: "p"; text: string }
  | { type: "h"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[] }
  | { type: "code"; text: string };

function parseBlocks(source: string): Block[] {
  const chunks = source.split(/```/);
  const blocks: Block[] = [];
  chunks.forEach((chunk, index) => {
    if (index % 2 === 1) {
      const text = chunk.replace(/^\w*\n/, "").replace(/\n$/, "");
      if (text.trim()) blocks.push({ type: "code", text });
      return;
    }
    const lines = chunk.replace(/\r\n/g, "\n").split("\n");
    let paragraph: string[] = [];
    let list: { kind: "ul" | "ol"; items: string[] } | null = null;

    const flushParagraph = () => {
      const text = paragraph.join(" ").trim();
      if (text) blocks.push({ type: "p", text });
      paragraph = [];
    };
    const flushList = () => {
      if (list && list.items.length) blocks.push({ type: list.kind, items: list.items });
      list = null;
    };

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) {
        flushParagraph();
        flushList();
        continue;
      }
      const heading = /^(#{1,3})\s+(.+)$/.exec(trimmed);
      if (heading) {
        flushParagraph();
        flushList();
        blocks.push({ type: "h", text: heading[2]! });
        continue;
      }
      const bullet = /^[-*]\s+(.+)$/.exec(trimmed);
      const ordered = /^\d+[.)]\s+(.+)$/.exec(trimmed);
      if (bullet || ordered) {
        flushParagraph();
        const kind = bullet ? "ul" : "ol";
        if (!list || list.kind !== kind) {
          flushList();
          list = { kind, items: [] };
        }
        list.items.push((bullet ?? ordered)![1]!);
        continue;
      }
      flushList();
      paragraph.push(trimmed);
    }
    flushParagraph();
    flushList();
  });
  return blocks;
}

export function MessageBody({ text }: { text: string }) {
  const blocks = parseBlocks(text);
  if (blocks.length === 0) return null;
  return (
    <div className="space-y-3 text-pretty">
      {blocks.map((block, index) => {
        if (block.type === "h") {
          return (
            <h3 key={index} className="font-display text-lg font-medium leading-snug tracking-tight">
              {inline(block.text)}
            </h3>
          );
        }
        if (block.type === "ul" || block.type === "ol") {
          const Tag = block.type === "ul" ? "ul" : "ol";
          return (
            <Tag key={index} className={block.type === "ul" ? "list-disc space-y-1 pl-5" : "list-decimal space-y-1 pl-5"}>
              {block.items.map((item, itemIndex) => (
                <li key={itemIndex}>{inline(item)}</li>
              ))}
            </Tag>
          );
        }
        if (block.type === "code") {
          return (
            <pre
              key={index}
              className="overflow-x-auto rounded-md bg-panel px-3 py-3 text-sm leading-relaxed text-ink"
            >
              <code>{block.text}</code>
            </pre>
          );
        }
        return <p key={index}>{inline(block.text)}</p>;
      })}
    </div>
  );
}
