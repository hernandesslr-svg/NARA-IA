import { useServerFn } from "@tanstack/react-start";
import {
  ArrowUp, BookOpen, ChevronLeft, Image as ImageIcon, Menu, Plus,
  Settings, Trash2, X, Bell, Palette, Globe, HardDrive, Shield, Info,
} from "lucide-react";
import { useEffect, useId, useRef, useState } from "react";
import { askNara } from "@/server/nara";
import {
  activeChat, appendAssistantMessage, appendUserMessage, deleteChat,
  selectChat, startNewChat, useNaraState,
} from "@/lib/nara-store";
import { MessageBody } from "@/components/nara/message-body";
import { getNaraCore } from "@/lib/nara-core-store";
import { generateWithLocalModel } from "@/lib/nara-local-model";

type Page = "chat" | "library" | "settings";

export function NaraApp() {
  const snapshot = useNaraState();
  const chat = activeChat(snapshot);
  const mode = chat?.mode ?? snapshot.draftMode;
  const ask = useServerFn(askNara);
  const [draft, setDraft] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [page, setPage] = useState<Page>("chat");
  const [theme, setTheme] = useState("Escuro");
  const [accent, setAccent] = useState("Roxo");
  const [libraryFilter, setLibraryFilter] = useState("Tudo");
  const threadRef = useRef<HTMLDivElement>(null);
  const fieldRef = useRef<HTMLTextAreaElement>(null);
  const fieldId = useId();

  useEffect(() => {
    threadRef.current?.scrollTo({ top: threadRef.current.scrollHeight });
  }, [chat?.messages.length, pending, chat?.id]);

  useEffect(() => {
    const node = fieldRef.current;
    if (!node) return;
    node.style.height = "0px";
    node.style.height = `${Math.min(node.scrollHeight, 160)}px`;
  }, [draft]);

  async function send(text: string) {
    const content = text.trim();
    if (!content || pending) return;
    setError(null);
    setDraft("");
    const messages = appendUserMessage(content, mode);
    setPending(true);
    try {
      const result = await ask({
        data: {
          mode,
          messages: messages.slice(-12).map((message) => ({ role: message.role, content: message.content })),
          core: getNaraCore(),
        },
      });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      if (result.source !== "nucleo-local" && result.source !== "calculo-local") {
        try {
          const generated = await generateWithLocalModel({
            query: content,
            conversation: messages.slice(-9, -1).map((message) => ({ role: message.role, content: message.content })),
            searchResults: result.source === "internet" ? result.text : "",
            mode,
          });
          if (generated.trim()) {
            appendAssistantMessage(generated);
            return;
          }
        } catch {
          // Keep the server's answer when the optional local model is unavailable.
        }
      }
      appendAssistantMessage(result.text);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não consegui falar com a Nara.");
    } finally {
      setPending(false);
      fieldRef.current?.focus();
    }
  }

  function newChat() {
    startNewChat();
    setDraft("");
    setError(null);
    setPage("chat");
    setMenuOpen(false);
  }

  function openPage(next: Page) {
    setPage(next);
    setMenuOpen(false);
  }

  const isEmpty = !chat || chat.messages.length === 0;

  return (
    <main className="nara-shell">
      <section className="nara-app">
        <header className="nara-header">
          <button type="button" className="icon-button" aria-label="Abrir menu" onClick={() => setMenuOpen(true)}>
            <Menu size={21} />
          </button>
          <h1>{page === "chat" ? "Nara" : page === "library" ? "Biblioteca" : "Configurações"}</h1>
          {page === "chat" && chat?.messages.length ? (
            <button type="button" className="icon-button" aria-label="Nova conversa" onClick={newChat}><Plus size={21} /></button>
          ) : page !== "chat" ? (
            <button type="button" className="icon-button" aria-label="Voltar ao chat" onClick={() => setPage("chat")}><ChevronLeft size={21} /></button>
          ) : <span className="header-spacer" />}
        </header>

        {page === "chat" ? (
          <>
            <div className="nara-thread" ref={threadRef}>
              {!isEmpty ? (
                <ol className="nara-messages">
                  {chat?.messages.map((message) => (
                    <li key={message.id} className={message.role === "user" ? "message-row user-row" : "message-row assistant-row"}>
                      {message.role === "user" ? (
                        <div className="user-bubble"><p>{message.content}</p></div>
                      ) : (
                        <div className="assistant-message"><p className="assistant-label">Nara</p><MessageBody text={message.content} /></div>
                      )}
                    </li>
                  ))}
                  {pending ? <li className="assistant-label thinking">Nara está pensando…</li> : null}
                </ol>
              ) : null}
            </div>
            <footer className="nara-composer-wrap">
              <form className="nara-composer" onSubmit={(event) => { event.preventDefault(); void send(draft); }}>
                <button type="button" className="icon-button add-button" aria-label="Nova conversa" onClick={newChat}><Plus size={22} /></button>
                <label htmlFor={fieldId} className="sr-only">Mensagem para Nara</label>
                <textarea
                  id={fieldId} ref={fieldRef} rows={1} value={draft} maxLength={4000}
                  placeholder="Digite sua mensagem…" disabled={pending}
                  onChange={(event) => setDraft(event.target.value)}
                  onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void send(draft); } }}
                />
                <button type="submit" className="send-button" aria-label="Enviar mensagem" disabled={pending || !draft.trim()}><ArrowUp size={22} /></button>
              </form>
              {error ? <p className="nara-error" role="alert">{error}</p> : null}
            </footer>
          </>
        ) : null}

        {page === "library" ? (
          <section className="simple-page">
            <div className="library-tabs">{["Tudo", "Imagens", "Documentos"].map((filter) => <button key={filter} type="button" className={libraryFilter === filter ? "selected" : ""} aria-pressed={libraryFilter === filter} onClick={() => setLibraryFilter(filter)}>{filter}</button>)}</div>
            <div className="empty-state"><div className="empty-icon"><ImageIcon size={28} /></div><h2>Sua biblioteca</h2><p>Imagens e arquivos que você guardar com a Nara aparecerão aqui.</p><span>A biblioteca ainda está vazia.</span></div>
          </section>
        ) : null}

        {page === "settings" ? (
          <section className="simple-page settings-page">
            <p className="settings-intro">Ajustes da Nara</p>
            <div className="settings-group">
              <p className="settings-group-title">Geral</p>
              <div className="setting-row"><span className="setting-icon"><Bell size={19} /></span><span className="setting-copy"><strong>Notificações</strong><small>Alertas e respostas</small></span><input aria-label="Notificações" type="checkbox" defaultChecked /></div>
              <div className="setting-row"><span className="setting-icon"><Palette size={19} /></span><span className="setting-copy"><strong>Aparência</strong><small>Tema e cor da interface</small></span><select aria-label="Tema" value={theme} onChange={(event) => setTheme(event.target.value)}><option>Escuro</option><option>Claro</option><option>Automático</option></select></div>
              <div className="setting-row"><span className="setting-icon"><Globe size={19} /></span><span className="setting-copy"><strong>Idioma</strong><small>Português (Brasil)</small></span><span className="setting-value">PT-BR</span></div>
              <div className="setting-row"><span className="setting-icon"><HardDrive size={19} /></span><span className="setting-copy"><strong>Armazenamento</strong><small>Dados salvos neste aparelho</small></span></div>
            </div>
            <div className="settings-group">
              <p className="settings-group-title">Privacidade</p>
              <div className="setting-row"><span className="setting-icon"><Shield size={19} /></span><span className="setting-copy"><strong>Privacidade</strong><small>Controle dos seus dados</small></span></div>
              <div className="setting-row"><span className="setting-icon"><Info size={19} /></span><span className="setting-copy"><strong>Sobre a Nara</strong><small>Informações do aplicativo</small></span></div>
            </div>
            <div className="settings-group">
              <p className="settings-group-title">Cor de destaque</p>
              <div className="accent-options" aria-label="Cor de destaque">
                {["Roxo", "Azul", "Rosa", "Vermelho", "Verde"].map((color) => <button key={color} type="button" aria-label={color} aria-pressed={accent === color} className={`accent-dot accent-${color.toLowerCase()} ${accent === color ? "active" : ""}`} onClick={() => setAccent(color)} />)}
              </div>
            </div>
          </section>
        ) : null}
      </section>

      {menuOpen ? (
        <div className="nara-drawer-layer">
          <button className="drawer-scrim" aria-label="Fechar menu" onClick={() => setMenuOpen(false)} />
          <nav className="nara-drawer" aria-label="Menu principal">
            <div className="drawer-heading"><span>Nara</span><button type="button" className="icon-button" aria-label="Fechar menu" onClick={() => setMenuOpen(false)}><X size={20} /></button></div>
            <button type="button" className="drawer-item primary" onClick={newChat}><Plus size={20} /><span>Nova conversa</span></button>
            <button type="button" className={`drawer-item ${page === "library" ? "current" : ""}`} onClick={() => openPage("library")}><BookOpen size={20} /><span>Biblioteca</span></button>
            <button type="button" className={`drawer-item ${page === "settings" ? "current" : ""}`} onClick={() => openPage("settings")}><Settings size={20} /><span>Configurações</span></button>
            <div className="drawer-bottom">
              <p>Conversas recentes</p>
              {snapshot.chats.length === 0 ? <span className="no-chats">Nenhuma conversa ainda.</span> : snapshot.chats.map((item) => (
                <div className="recent-chat" key={item.id}>
                  <button type="button" className="recent-chat-title" onClick={() => { selectChat(item.id); openPage("chat"); }}>{item.title || "Conversa"}</button>
                  <button type="button" className="recent-delete" aria-label={`Apagar ${item.title || "conversa"}`} onClick={() => deleteChat(item.id)}><Trash2 size={15} /></button>
                </div>
              ))}
            </div>
          </nav>
        </div>
      ) : null}
    </main>
  );
}
