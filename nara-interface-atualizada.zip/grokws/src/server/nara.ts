import { createServerFn } from "@tanstack/react-start";
import { sanitizeCore, TRAINED_CORE } from "@/lib/nara-core";
import { isModeId } from "@/lib/nara-modes";

type ChatTurn = { role: "user" | "assistant"; content: string };

function normalize(value: string) {
  return value.toLocaleLowerCase("pt-BR").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
}
function tokens(value: string) {
  return new Set(normalize(value).split(/\s+/).filter((word) => word.length > 2));
}
function overlap(query: string, candidate: string) {
  const a = tokens(query), b = tokens(candidate);
  if (!a.size || !b.size) return 0;
  let common = 0;
  for (const word of a) if (b.has(word)) common++;
  return common / Math.sqrt(a.size * b.size);
}

const numberWords: Record<string, string> = {
  zero: "0", um: "1", uma: "1", dois: "2", duas: "2", tres: "3", quatro: "4",
  cinco: "5", seis: "6", sete: "7", oito: "8", nove: "9", dez: "10",
  onze: "11", doze: "12", treze: "13", quatorze: "14", catorze: "14", quinze: "15",
  dezesseis: "16", dezessete: "17", dezoito: "18", dezenove: "19", vinte: "20",
};

/** Handle exact, deterministic arithmetic locally before searching the web. */
function calculateArithmetic(query: string): string | null {
  let normalized = normalize(query);
  normalized = normalized.replace(/\b([a-z]+)\b/g, (word) => numberWords[word] ?? word);
  const match = normalized.match(/(?:quanto e|quanto da|calcule|calcula|resolva|resultado de)?\s*(-?\d+(?:[.,]\d+)?)\s*(mais|menos|vezes|multiplicado por|dividido por|dividido|\+|-|\*|x|\/|por)\s*(-?\d+(?:[.,]\d+)?)(?:\s*[?!.]*)?$/);
  if (!match) return null;
  const a = Number(match[1].replace(",", "."));
  const b = Number(match[3].replace(",", "."));
  const operator = match[2];
  let result: number;
  if (["mais", "+"].includes(operator)) result = a + b;
  else if (["menos", "-"].includes(operator)) result = a - b;
  else if (["vezes", "multiplicado por", "*", "x", "por"].includes(operator)) result = a * b;
  else if (["dividido por", "dividido", "/"].includes(operator)) {
    if (b === 0) return "Não é possível dividir por zero.";
    result = a / b;
  } else return null;
  if (!Number.isFinite(result)) return null;
  const formatted = Number.isInteger(result) ? String(result) : String(Number(result.toPrecision(10)));
  return `${formatted}. Fiz o cálculo diretamente, sem precisar pesquisar na internet.`;
}

function localAnswer(mode: string, messages: ChatTurn[], inputCore: unknown): string | null {
  const core = sanitizeCore(inputCore);
  const query = messages[messages.length - 1]?.content?.trim() ?? "";
  const q = normalize(query);
  const conversational: Array<[RegExp, string]> = [
    [/^(oi|ola|e ai|eae|opa|oie|hey|hello)$/, "Oi! Estou aqui. O que você gostaria de conversar?"],
    [/^(bom dia)$/, "Bom dia! Como posso ajudar você hoje?"],
    [/^(boa tarde)$/, "Boa tarde! O que vamos resolver hoje?"],
    [/^(boa noite)$/, "Boa noite! Quer conversar ou precisa de ajuda com alguma coisa?"],
    [/^(tudo bem|como vai|como voce esta|td bem)$/, "Tudo certo por aqui e pronta para conversar. E você, como está?"],
    [/^(obrigado|obrigada|valeu|brigado|brigada)$/, "Por nada!"],
    [/^(tchau|ate logo|falou|ate mais)$/, "Até mais! Quando quiser continuar, é só voltar."],
    [/^(quem e voce|qual seu nome|seu nome)$/, "Sou a Nara, uma assistente que funciona com regras locais e exemplos armazenados neste aplicativo."],
    [/^(o que voce sabe fazer|como voce pode ajudar)$/, "Posso recuperar exemplos do meu núcleo, responder a cumprimentos e ajudar em tarefas que estejam cobertas pelo conteúdo local. Ainda tenho limitações para perguntas novas e complexas."],
  ];
  for (const [pattern, answer] of conversational) if (pattern.test(q)) return answer;

  const lessons = core.lessons.length ? core.lessons : TRAINED_CORE.lessons;
  const ranked = lessons.map((lesson) => ({ lesson, score: Math.max(overlap(query, lesson.user), overlap(query, `${lesson.user} ${lesson.assistant}`) * 0.8) }))
    .sort((a, b) => b.score - a.score);
  const best = ranked[0];
  if (best && best.score >= 0.48) {
    return best.lesson.assistant;
  }

  if (/^(continua|continue|pode continuar|e depois|proximo passo)$/.test(q)) {
    return "Posso continuar, mas preciso identificar o assunto anterior. Diga qual parte você quer desenvolver.";
  }
  if (/^(mais|faz mais|coloca mais|detalha|explica melhor)$/.test(q)) {
    return "Posso aprofundar. Diga qual ponto você quer ampliar para eu não repetir o que já foi explicado.";
  }
  // Null means the local nucleus did not find a sufficiently relevant answer;
  // the request handler will then attempt a public web search.
  return null;
}

function decodeHtml(value: string) {
  return value.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ");
}

function stripHtml(value: string) {
  return decodeHtml(value.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
}

async function searchInternet(query: string): Promise<string | null> {
  // Search is a fallback only: locally matched answers are preferred first.
  // DuckDuckGo's HTML endpoint returns public search snippets without an API key.
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 6500);
  try {
    const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query.slice(0, 350))}`;
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { "User-Agent": "Mozilla/5.0 (compatible; NaraAssistant/1.0)" },
    });
    if (!response.ok) return null;
    const html = await response.text();
    const results: Array<{ title: string; snippet: string; url: string }> = [];
    const blocks = html.match(/<div class="result[^>]*>[\s\S]*?<\/div>\s*<\/div>/gi) ?? [];
    for (const block of blocks) {
      const link = block.match(/<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
      const snippet = block.match(/<a[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/a>|<div[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/div>/i);
      if (!link) continue;
      let resultUrl = decodeHtml(link[1]);
      const uddg = resultUrl.match(/[?&]uddg=([^&]+)/);
      if (uddg) { try { resultUrl = decodeURIComponent(uddg[1]); } catch { /* keep original URL */ } }
      if (!/^https?:\/\//i.test(resultUrl)) continue;
      const title = stripHtml(link[2]);
      const summary = stripHtml(snippet?.[1] ?? snippet?.[2] ?? "");
      if (title && summary) results.push({ title, snippet: summary, url: resultUrl });
      if (results.length >= 4) break;
    }
    if (!results.length) return null;
    return `Não encontrei uma resposta suficientemente próxima no meu núcleo local, então pesquisei na internet. Aqui estão os resultados encontrados:\n\n${results.map((r, i) => `${i + 1}. ${r.title}\n${r.snippet}\nFonte: ${r.url}`).join("\n\n")}\n\nEsses são trechos dos resultados da pesquisa, não uma verificação independente de todos os fatos. Confira as fontes para detalhes e contexto.`;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

export const askNara = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object") throw new Error("Pedido inválido.");
    const data = input as { mode?: unknown; messages?: unknown; core?: unknown };
    if (!isModeId(data.mode)) throw new Error("Modo inválido.");
    if (!Array.isArray(data.messages) || data.messages.length === 0 || data.messages.length > 12) {
      throw new Error("Histórico inválido.");
    }
    const messages: ChatTurn[] = data.messages.map((item) => {
      if (!item || typeof item !== "object") throw new Error("Mensagem inválida.");
      const message = item as { role?: unknown; content?: unknown };
      if (message.role !== "user" && message.role !== "assistant") throw new Error("Mensagem inválida.");
      if (typeof message.content !== "string") throw new Error("Mensagem inválida.");
      const content = message.content.trim();
      if (!content || content.length > 4000) throw new Error("Cada mensagem precisa ter até 4000 caracteres.");
      return { role: message.role, content };
    });
    if (messages[messages.length - 1]?.role !== "user") {
      throw new Error("A última mensagem precisa ser sua.");
    }
    return { mode: data.mode, messages, core: sanitizeCore(data.core) };
  })
  .handler(async ({ data }) => {
    const query = data.messages[data.messages.length - 1]?.content?.trim() ?? "";
    const calculation = calculateArithmetic(query);
    if (calculation) return { ok: true as const, text: calculation, source: "calculo-local" as const };
    const local = localAnswer(data.mode, data.messages, data.core);
    if (local) return { ok: true as const, text: local, source: "nucleo-local" as const };
    const web = await searchInternet(query);
    if (web) return { ok: true as const, text: web, source: "internet" as const };
    return {
      ok: true as const,
      text: "Não encontrei uma resposta suficientemente próxima no meu núcleo e não consegui obter resultados da internet agora. Confira sua conexão ou tente reformular a pergunta.",
      source: "sem-resultados" as const,
    };
  });
