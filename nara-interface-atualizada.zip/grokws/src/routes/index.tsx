import { createFileRoute } from "@tanstack/react-router";
import { NaraApp } from "@/components/nara/nara-app";

export const Route = createFileRoute("/")({ component: NaraApp });
