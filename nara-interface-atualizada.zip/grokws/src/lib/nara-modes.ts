export const MODES = [
  {
    id: "livre",
    label: "Livre",
    hint: "Conversa aberta",
    placeholder: "Escreva para a Nara",
  },
  {
    id: "explicar",
    label: "Explicar",
    hint: "Ensina com um exemplo",
    placeholder: "O que você quer entender?",
  },
  {
    id: "escrever",
    label: "Escrever",
    hint: "Redige o texto",
    placeholder: "O que precisa ser escrito?",
  },
  {
    id: "planejar",
    label: "Planejar",
    hint: "Transforma em passos",
    placeholder: "O que você quer organizar?",
  },
] as const;

export type ModeId = (typeof MODES)[number]["id"];

export function isModeId(value: unknown): value is ModeId {
  return MODES.some((mode) => mode.id === value);
}

export function modeById(id: ModeId) {
  return MODES.find((mode) => mode.id === id) ?? MODES[0];
}
