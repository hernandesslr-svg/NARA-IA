import { useSyncExternalStore } from "react";
import { isModeId, type ModeId } from "@/lib/nara-modes";

export type NaraMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
};

export type NaraChat = {
  id: string;
  title: string;
  mode: ModeId;
  messages: NaraMessage[];
  updatedAt: number;
};

type NaraState = {
  chats: NaraChat[];
  activeId: string | null;
  draftMode: ModeId;
};

const STORAGE_KEY = "nara-chats-v1";
const EMPTY: NaraState = { chats: [], activeId: null, draftMode: "livre" };

const listeners = new Set<() => void>();
let state: NaraState = EMPTY;

function uid() {
  return crypto.randomUUID();
}

function sanitize(raw: unknown): NaraState {
  if (!raw || typeof raw !== "object") return EMPTY;
  const data = raw as Partial<NaraState>;
  const chats = Array.isArray(data.chats) ? data.chats : [];
  const clean: NaraChat[] = [];
  for (const item of chats.slice(0, 30)) {
    if (!item || typeof item !== "object") continue;
    const chat = item as Partial<NaraChat>;
    if (typeof chat.id !== "string" || typeof chat.title !== "string") continue;
    if (!isModeId(chat.mode)) continue;
    const messages: NaraMessage[] = [];
    if (Array.isArray(chat.messages)) {
      for (const entry of chat.messages.slice(-80)) {
        if (!entry || typeof entry !== "object") continue;
        const message = entry as Partial<NaraMessage>;
        if (message.role !== "user" && message.role !== "assistant") continue;
        if (typeof message.content !== "string" || !message.content) continue;
        messages.push({
          id: typeof message.id === "string" ? message.id : uid(),
          role: message.role,
          content: message.content.slice(0, 8000),
        });
      }
    }
    clean.push({
      id: chat.id,
      title: chat.title.slice(0, 80) || "Conversa",
      mode: chat.mode,
      messages,
      updatedAt: typeof chat.updatedAt === "number" ? chat.updatedAt : Date.now(),
    });
  }
  const activeId = clean.some((chat) => chat.id === data.activeId) ? (data.activeId ?? null) : (clean[0]?.id ?? null);
  return {
    chats: clean,
    activeId,
    draftMode: isModeId(data.draftMode) ? data.draftMode : "livre",
  };
}

function load() {
  if (typeof window === "undefined") return;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    state = sanitize(JSON.parse(raw));
  } catch {
    state = EMPTY;
  }
}

load();

function emit(next: NaraState) {
  state = next;
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* storage full or blocked — keep the session in memory */
    }
  }
  listeners.forEach((listener) => listener());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useNaraState() {
  return useSyncExternalStore(subscribe, () => state, () => EMPTY);
}

export function activeChat(snapshot: NaraState) {
  return snapshot.chats.find((chat) => chat.id === snapshot.activeId) ?? null;
}

export function setDraftMode(mode: ModeId) {
  const current = activeChat(state);
  if (!current) {
    emit({ ...state, draftMode: mode });
    return;
  }
  emit({
    ...state,
    draftMode: mode,
    chats: state.chats.map((chat) => (chat.id === current.id ? { ...chat, mode } : chat)),
  });
}

export function selectChat(id: string) {
  const chat = state.chats.find((item) => item.id === id);
  if (!chat) return;
  emit({ ...state, activeId: id, draftMode: chat.mode });
}

export function startNewChat() {
  emit({ ...state, activeId: null });
}

export function deleteChat(id: string) {
  const chats = state.chats.filter((chat) => chat.id !== id);
  const activeId = state.activeId === id ? (chats[0]?.id ?? null) : state.activeId;
  const nextActive = chats.find((chat) => chat.id === activeId);
  emit({
    chats,
    activeId,
    draftMode: nextActive?.mode ?? state.draftMode,
  });
}

export function appendUserMessage(content: string, mode: ModeId) {
  const message: NaraMessage = { id: uid(), role: "user", content };
  const current = activeChat(state);
  if (!current) {
    const chat: NaraChat = {
      id: uid(),
      title: content.replace(/\s+/g, " ").slice(0, 48),
      mode,
      messages: [message],
      updatedAt: Date.now(),
    };
    emit({ ...state, activeId: chat.id, draftMode: mode, chats: [chat, ...state.chats].slice(0, 30) });
    return chat.messages;
  }
  const messages = [...current.messages, message];
  const title = current.messages.length === 0 ? content.replace(/\s+/g, " ").slice(0, 48) : current.title;
  const updated: NaraChat = { ...current, mode, title, messages, updatedAt: Date.now() };
  emit({
    ...state,
    draftMode: mode,
    chats: [updated, ...state.chats.filter((chat) => chat.id !== current.id)],
  });
  return messages;
}

export function appendAssistantMessage(content: string) {
  const current = activeChat(state);
  if (!current) return;
  const updated: NaraChat = {
    ...current,
    messages: [...current.messages, { id: uid(), role: "assistant", content }],
    updatedAt: Date.now(),
  };
  emit({
    ...state,
    chats: state.chats.map((chat) => (chat.id === current.id ? updated : chat)),
  });
}
