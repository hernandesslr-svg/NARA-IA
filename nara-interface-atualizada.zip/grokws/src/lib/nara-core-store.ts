import { useSyncExternalStore } from "react";
import { sanitizeCore, TRAINED_CORE, type NaraCore, type NaraLesson } from "@/lib/nara-core";

const STORAGE_KEY = "nara-core-v2";
const listeners = new Set<() => void>();
let state: NaraCore = TRAINED_CORE;

function load() {
  if (typeof window === "undefined") return;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const saved = sanitizeCore(JSON.parse(raw));
    // Upgrade the existing local nucleus without discarding the user's voice,
    // facts, or lessons. New built-in knowledge is appended only when missing.
    const normalizeKey = (value: string) => value.trim().toLocaleLowerCase("pt-BR").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
    const factKey = normalizeKey;
    const lessonKey = normalizeKey;
    const facts = [...saved.facts];
    const knownFacts = new Set(facts.map(factKey));
    for (const fact of TRAINED_CORE.facts) {
      if (!knownFacts.has(factKey(fact))) {
        facts.push(fact);
        knownFacts.add(factKey(fact));
      }
    }
    const lessons = [...saved.lessons];
    const knownPrompts = new Set(lessons.map((lesson) => lessonKey(lesson.user)));
    for (const lesson of TRAINED_CORE.lessons) {
      if (!knownPrompts.has(lessonKey(lesson.user))) {
        lessons.push(lesson);
        knownPrompts.add(lessonKey(lesson.user));
      }
    }
    state = sanitizeCore({ ...saved, facts, lessons });
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    state = TRAINED_CORE;
  }
}

load();

function emit(next: NaraCore) {
  state = next;
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* keep the session in memory */
    }
  }
  listeners.forEach((listener) => listener());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useNaraCore() {
  return useSyncExternalStore(subscribe, () => state, () => TRAINED_CORE);
}

export function getNaraCore() {
  return state;
}

export function saveVoice(voice: string) {
  emit(sanitizeCore({ ...state, voice }));
}

export function addFact(fact: string) {
  const next = fact.trim();
  if (!next) return;
  emit(sanitizeCore({ ...state, facts: [...state.facts, next] }));
}

export function removeFact(index: number) {
  emit(sanitizeCore({ ...state, facts: state.facts.filter((_, item) => item !== index) }));
}

export function addLesson(lesson: Pick<NaraLesson, "user" | "assistant">) {
  const user = lesson.user.trim();
  const assistant = lesson.assistant.trim();
  if (!user || !assistant) return;
  const normalizeKey = (value: string) => value.trim().toLocaleLowerCase("pt-BR").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
  const key = normalizeKey(user);
  const without = state.lessons.filter((item) => normalizeKey(item.user) !== key);
  const id = crypto.randomUUID();
  emit(sanitizeCore({ ...state, lessons: [{ id, user, assistant }, ...without] }));
}

export function removeLesson(id: string) {
  emit(sanitizeCore({ ...state, lessons: state.lessons.filter((lesson) => lesson.id !== id) }));
}

export function resetCore() {
  emit(TRAINED_CORE);
}
