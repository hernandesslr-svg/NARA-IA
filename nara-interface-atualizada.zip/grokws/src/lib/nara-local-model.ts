/**
 * Optional in-browser language model for Nara.
 * No Grok/xAI/OpenAI API is used. The WebLLM runtime and model weights are
 * downloaded on first use, then cached by the browser when storage permits.
 * Requires a browser with WebGPU; callers should gracefully fall back otherwise.
 */

type ChatMessage = { role: "user" | "assistant"; content: string };
type WebLLMEngine = {
  chat: {
    completions: {
      create: (args: {
        messages: Array<{ role: "system" | "user" | "assistant"; content: string }>;
        temperature?: number;
        max_tokens?: number;
      }) => Promise<{ choices?: Array<{ message?: { content?: string | null } }> }>;
    };
  };
};
type WebLLMModule = {
  CreateMLCEngine: (model: string, options?: { initProgressCallback?: (progress: { text?: string }) => void }) => Promise<WebLLMEngine>;
};

const MODEL_ID = "Qwen2.5-0.5B-Instruct-q4f16_1-MLC";
let enginePromise: Promise<WebLLMEngine> | null = null;

async function getEngine(): Promise<WebLLMEngine> {
  if (typeof window === "undefined") throw new Error("O modelo local precisa do navegador.");
  if (!("gpu" in navigator)) throw new Error("Este navegador não oferece WebGPU para executar o modelo local.");
  if (!enginePromise) {
    enginePromise = (async () => {
      // External ESM keeps the application bundle small; model execution remains local.
      const moduleUrl: string = "https://esm.run/@mlc-ai/web-llm";
      const runtime = (await import(/* @vite-ignore */ moduleUrl)) as WebLLMModule;
      return runtime.CreateMLCEngine(MODEL_ID);
    })().catch((error) => {
      enginePromise = null;
      throw error;
    });
  }
  return enginePromise;
}

export async function generateWithLocalModel(input: {
  query: string;
  conversation: ChatMessage[];
  searchResults?: string;
  mode: string;
}): Promise<string> {
  const engine = await getEngine();
  const system = [
    "Você é Nara, uma assistente de IA independente, que responde em português brasileiro.",
    "Seja útil, clara, natural e específica. Não diga que é o Grok nem mencione provedores de IA.",
    "Não invente fatos, links, citações, preços ou acontecimentos atuais. Se não souber, admita a incerteza.",
    "Use o histórico recente para entender referências como 'isso', 'continua' e 'explica melhor'.",
    `Modo de resposta: ${input.mode}.`,
    input.searchResults
      ? "A seguir há resultados públicos de pesquisa. Sintetize-os para responder à pergunta, preserve URLs relevantes e não acrescente fatos atuais que não estejam apoiados nos resultados. Se os resultados não forem suficientes, diga isso.\n\nRESULTADOS DA WEB:\n" + input.searchResults
      : "Responda usando o conhecimento disponível no modelo. Para fatos atuais ou incertos, deixe claro que não foram verificados na internet nesta resposta.",
  ].join("\n\n");
  const history = input.conversation.slice(-8).map((message) => ({ role: message.role, content: message.content }));
  const result = await engine.chat.completions.create({
    messages: [{ role: "system", content: system }, ...history, { role: "user", content: input.query }],
    temperature: 0.55,
    max_tokens: 700,
  });
  return result.choices?.[0]?.message?.content?.trim() ?? "";
}
